/*var app = new Vue({
  el: '#app',
  data: function() {
    return {
      publicaciones: {}
    }
  },
  mounted () {
  axios
    .get('https://www.instagram.com/explore/tags/mcguate/?__a=1')
    .then(response => (this.publicaciones = response))
}
});
*/
